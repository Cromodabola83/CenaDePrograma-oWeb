<?php
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $sub = $_POST['sub'];
    if($sub==1){
        session_start();
        session_destroy();
    }
    header("Location: index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="css/logout.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<title>AdminHub</title>
</head>
<body>

<div class="split left">
  <div class="centered">
    <form action="" method="post" class="logout">
        <input type="hidden" value="1" class="logout" name="sub">
        <input type="submit" class="btn btn-danger" value="LOGOUT">
    </form>
    <br>
    <p>If you press on LOGOUT your account will end its session on this site</p>
  </div>
</div>

<div class="split right">
  <div class="centered">
    <form action="" method="post" class="cancel">
        <input type="hidden" value="2" class="cancel" name="sub">
        <input type="submit" class="btn btn-primary" value="CANCEL">
    </form>
    <br>
    <p>If you press on CANCEL your account will remain loged in the site</p>
  </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>