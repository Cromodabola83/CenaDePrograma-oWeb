<?php
if (! isset($_GET['page']))
{
    include('./dashboard.php');
}else{
$page=$_GET['page'];
switch($page)
{
    case 'dashboard':
    include 'dashboard.php';
    break;
    case 'mystore':
    include 'mystore.php';
    break;
    case 'analytics':
    include 'analytics.php';
    break;
    case 'message':
    include 'message.php';
    break;
    case 'team':
    include 'team.php';
    break;
    case 'settings':
    include 'settings.php';
    break;
}
}


?>
